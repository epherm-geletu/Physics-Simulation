package sim;
import java.util.ArrayList;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.util.Duration;

public class simer extends Application {
	static double delta=0.01,g=10;
	static Timeline repeat;
	public static void main(String []args) {
		launch(args);
	}

	@Override
	public void start(Stage Window) throws Exception {
		Pane root = new Pane();
		Scene Login = new Scene(root);
		
		ArrayList <Ball> balls = new ArrayList<>();
		balls.add(new Ball(root));
		
		root.setOnMouseClicked(e->{balls.add(new Ball(root,e.getX(),e.getY()));
								System.out.println(e.getX());});
		
		Window.setScene(Login);
		Window.setWidth(360);
		Window.setHeight(420);
		
		repeat = new Timeline(new KeyFrame(Duration.seconds(delta),e ->{
			
			for(int i=0;i<balls.size();i++){
			Ball myball = balls.get(i);
			double windhieght=Window.getHeight()-40-((Circle) myball.ball).getRadius(),radius=((Circle) myball.ball).getRadius();
			
			for(int j=i+1;j<balls.size();j++) {	
				Ball otherballs = balls.get(j);

				double xdistance = Math.abs(otherballs.posx-myball.posx);
				double ydistance = Math.abs(otherballs.posy-myball.posy);
				double restDistance=((Circle) otherballs.ball).getRadius()+((Circle) myball.ball).getRadius();
				boolean collide =(xdistance*xdistance)+(ydistance*ydistance) <= restDistance*restDistance;
				
				if(collide) {
					ydistance=(ydistance<5)?0:ydistance;
					xdistance=(xdistance<5)?0:xdistance;
					
					if(ydistance!=0 && (myball.posy<=windhieght || otherballs.posy<=(windhieght))) {
					myball.posy += ((restDistance-ydistance)*Math.signum(myball.posy-otherballs.posy))/2*30*delta;
					otherballs.posy += ((restDistance-ydistance)*Math.signum(otherballs.vy-myball.posy))/2*30*delta;}
					
					if(xdistance!=0) {
					myball.posx += ((restDistance-xdistance)*Math.signum(myball.posx-otherballs.posx))/2*30*delta;
					otherballs.posx += ((restDistance-xdistance)*Math.signum(otherballs.vx-myball.posx))/2*30*delta;}
					
					if(!(otherballs.trying && myball.trying)){
					double tempx=myball.vx;
					double tempy=myball.vy;
					myball.vy = otherballs.vy;
					myball.vx = otherballs.vx;
					otherballs.vy = tempy;
					otherballs.vx = tempx;
					otherballs.trying=true;
					myball.trying=true;
					}
					else{
						otherballs.trying=false;
						myball.trying=false;}
					}
					
				
				}
			
			//border collision
			if(myball.posx<=radius && myball.vx<=0 || myball.posx>=Window.getWidth()-radius-16 && myball.vx>=0){
				myball.vx=-0.8*myball.vx;
			}
			if((myball.posy>=(windhieght) && myball.vy>=0 || myball.posy<0 && myball.vy<=0)){
				myball.vy = -myball.vy;
			}
			
			//update gravity and stuff
			if((myball.posy<=(windhieght))){
				myball.vy+= 20*g*delta;
				}
			if((myball.posy>(windhieght))){
				myball.posy = windhieght;
				}
			myball.posy += myball.vy*delta;
			myball.posx += myball.vx*delta;
			
			//damp
			if(myball.posy<=(windhieght)){
				myball.posy += myball.damp;
			}
			
			myball.setballPos();}
		}));
		repeat.setCycleCount(Timeline.INDEFINITE);
		repeat.play();
		
		Window.show();
	}
		
}

class Ball{
	boolean trying=false;
	double posx=360/2,posy=0,vy=-Math.random()*360,vx=Math.random()*360,damp=0.01*50;
	Shape ball = new Circle(Math.random()*20+10);
	Ball(Pane root,double xloc,double yloc){
		ball.setStyle("-fx-fill: hsb("+(Math.random()*360)+",90%,80%);");
		ball.setTranslateX(xloc);
		posx=xloc;
		posy=yloc;
		ball.setTranslateY(yloc);
		root.getChildren().add(ball);
	}
	Ball(Pane root){
		ball.setStyle("-fx-fill: hsb("+(Math.random()*360)+",90%,80%);");
		ball.setTranslateX(posx);
		root.getChildren().add(ball);
	}
	
	void setballPos(){
		ball.setTranslateY(posy);
		ball.setTranslateX(posx);
	}
}
